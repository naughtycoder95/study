package com.example.ControllerExam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControllerExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControllerExamApplication.class, args);
	}

}
